package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CustomerService {
    @Autowired
    private CustomerRepository repo;

    public List<Customer> listAll() {
        return repo.findAll();
    }

    public Customer get(Integer id) {
        return repo.findById(id).orElse(null); // Use `orElse(null)` to handle the possibility of a non-existent user
    }

    public void save(Customer customer) {
        repo.save(customer);
    }

    public void delete(Integer id) {
        repo.deleteById(id);
    }
}
